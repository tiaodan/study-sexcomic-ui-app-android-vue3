package com.study.ui_sexcomic;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
