import{_ as e}from"./_plugin-vue_export-helper-DlAUqK2U.js";import{c as r,o as c}from"./index-9BQjC0tO.js";const o={};function n(t,s){return c(),r("div",null,"朋友")}const f=e(o,[["render",n]]);export{f as default};
//# sourceMappingURL=Friend-DH7hcspv.js.map
