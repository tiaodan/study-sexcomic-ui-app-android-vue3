import{_ as e}from"./_plugin-vue_export-helper-DlAUqK2U.js";import{c,o as r}from"./index-9BQjC0tO.js";const o={};function t(n,a){return r(),c("div",null,"搜索")}const f=e(o,[["render",t]]);export{f as default};
//# sourceMappingURL=Search-C-TcCOCV.js.map
