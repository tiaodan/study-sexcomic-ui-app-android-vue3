import{_ as e}from"./_plugin-vue_export-helper-DlAUqK2U.js";import{c as t,o as c}from"./index-B8fT5vIT.js";const o={};function r(n,s){return c(),t("div",null,"设置")}const f=e(o,[["render",r]]);export{f as default};
//# sourceMappingURL=Setting-BzpKiX-d.js.map
